 function changeToBlue(){
        document.getElementById('green-p').style.color="blue";

    }
    function changeToRed(){
        document.getElementById('green-p').style.color="red";

    }
    function facebook(){
        document.getElementById('myImage').setAttribute('src','../img/facebook.jpg');

    }
    function youtube(){
        document.getElementById('myImage').setAttribute('src','../img/youtube.jpg');

    }